// Minimal backend for real key validation.
// Run: npm install && npm start
const express=require("express");
const crypto=require("crypto");
const path=require("path");
const app=express();
app.use(express.json());
app.use(express.static(path.join(__dirname,"public")));

const PORT=process.env.PORT||3000;
const ADMIN_TOKEN=process.env.ADMIN_TOKEN||"change-me";
const keys=new Map();

const DUR={h1:3600,d1:86400,d3:259200,d7:604800};
function makeKey(){return "MP-"+crypto.randomBytes(5).toString("hex").toUpperCase()+"-"+crypto.randomBytes(3).toString("hex").toUpperCase()}

app.post("/api/admin/create-key",(req,res)=>{
  if(req.headers.authorization!==`Bearer ${ADMIN_TOKEN}`)return res.status(401).json({ok:false});
  const plan=req.body.plan||"d1";
  if(!DUR[plan])return res.status(400).json({ok:false,message:"Unknown plan"});
  const key=makeKey(); keys.set(key,{plan,createdAt:Date.now(),expiresAt:null,used:false});
  res.json({ok:true,key,plan});
});

app.post("/api/activate",(req,res)=>{
  const key=String(req.body.key||"").trim().toUpperCase();
  const item=keys.get(key);
  if(!item)return res.status(400).json({ok:false,message:"Invalid key"});
  if(item.used && item.expiresAt && item.expiresAt<Date.now())return res.status(400).json({ok:false,message:"Expired"});
  if(!item.used){
    item.used=true; item.expiresAt=Date.now()+DUR[item.plan]*1000;
  }
  const labels={h1:"1 hour",d1:"1 day",d3:"3 days",d7:"7 days"};
  res.json({ok:true,plan:item.plan,planLabel:labels[item.plan],expiresAt:item.expiresAt});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log("Mirror Access running on "+PORT));
