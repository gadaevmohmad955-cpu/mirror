const RAW_SCRIPT_URL="https://pastefy.app/lne9k0Rj/raw";
const API_BASE="/api";
const TASK_URL="#"; // Put your YouTube/task URL here.

const $=s=>document.querySelector(s);
const toast=(t)=>{const e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),1800)};
const langs={en:{
navScript:"Script",navAccess:"Access",navPro:"Pro",eyebrow:"MIRROR PLAYER",heroTitle:"A clean way to launch your script.",
heroText:"Activate access, copy the latest script, and keep your access status in one place.",getAccess:"Get access",
copyScript:"Copy script",statusLive:"System online",sectionScript:"SCRIPT",scriptTitle:"Mirror Player",latest:"Latest",
scriptDesc:"Player mirroring, smooth follow, animations, settings and local BTools.",copy:"Copy",raw:"Raw",
sectionAccess:"ACCESS",accessTitle:"Choose your access",freeAccess:"Free access",oneDay:"One-day access",
threeDays:"Three-day access",sevenDays:"Seven-day access",proDesc:"No key system",proTitle:"One subscription. No key flow.",
proText:"Pro can permanently skip the free-access flow while your subscription is active.",buyPro:"Get Pro — $4",
activateEyebrow:"ACTIVATE",activateTitle:"Unlock your script",activateText:"Enter your access code. New codes must be issued by the server.",
activate:"Activate",getKey:"Get a key",activeAccess:"ACTIVE ACCESS",expiresIn:"Expires in",chooseLanguage:"Language",
footer:"Use only in games/projects you own or are authorized to test."},
ru:{
navScript:"Скрипт",navAccess:"Доступ",navPro:"Pro",eyebrow:"MIRROR PLAYER",heroTitle:"Чистый и удобный запуск скрипта.",
heroText:"Активируй доступ, копируй последнюю версию скрипта и следи за сроком доступа в одном месте.",getAccess:"Получить доступ",
copyScript:"Копировать скрипт",statusLive:"Система онлайн",sectionScript:"СКРИПТ",scriptTitle:"Mirror Player",latest:"Последняя версия",
scriptDesc:"Зеркалирование игрока, плавное следование, анимации, настройки и локальные BTools.",copy:"Копировать",raw:"Raw",
sectionAccess:"ДОСТУП",accessTitle:"Выбери доступ",freeAccess:"Бесплатный доступ",oneDay:"Доступ на 1 день",
threeDays:"Доступ на 3 дня",sevenDays:"Доступ на 7 дней",proDesc:"Без системы ключей",proTitle:"Одна подписка. Без ключей.",
proText:"Pro может полностью отключить бесплатную систему ключей на время подписки.",buyPro:"Получить Pro — $4",
activateEyebrow:"АКТИВАЦИЯ",activateTitle:"Открой доступ к скрипту",activateText:"Введи код доступа. Новые коды выдаются сервером.",
activate:"Активировать",getKey:"Получить ключ",activeAccess:"АКТИВНЫЙ ДОСТУП",expiresIn:"Истекает через",chooseLanguage:"Язык",
footer:"Используй только в своих играх/проектах или там, где у тебя есть разрешение на тестирование."}};

let lang=localStorage.getItem("mp_lang")||"en";
function applyLang(){
  document.documentElement.lang=lang;
  document.querySelectorAll("[data-i18n]").forEach(e=>{
    const k=e.dataset.i18n;if(langs[lang][k])e.textContent=langs[lang][k];
  });
  $("#flag").textContent=lang==="ru"?"🇷🇺":"🇺🇸";$("#langName").textContent=lang.toUpperCase();
}
applyLang();

async function copyScript(){
  try{
    const r=await fetch(RAW_SCRIPT_URL,{cache:"no-store"});
    if(!r.ok)throw new Error();
    const text=await r.text();
    await navigator.clipboard.writeText(text);
    toast(lang==="ru"?"Скрипт скопирован":"Script copied");
  }catch(e){
    toast(lang==="ru"?"Не удалось получить скрипт":"Could not fetch script");
  }
}
$("#copyScript").onclick=copyScript;$("#copyHero").onclick=copyScript;$("#showCopy").onclick=copyScript;
$("#openRaw").onclick=()=>window.open(RAW_SCRIPT_URL,"_blank","noopener");
$("#getAccess").onclick=()=>{$("#activation").classList.remove("hidden");$("#activation").scrollIntoView({behavior:"smooth"})};
$("#youtubeTask").href=TASK_URL;

document.querySelectorAll(".plan").forEach(p=>p.onclick=()=>{
  if(p.dataset.plan==="pro"){toast(lang==="ru"?"Pro требует подключения оплаты на сервере":"Pro requires payment integration on the server");return}
  $("#activation").classList.remove("hidden");$("#activation").scrollIntoView({behavior:"smooth"});
});

$("#langBtn").onclick=()=>$("#langModal").classList.remove("hidden");
$("#closeLang").onclick=()=>$("#langModal").classList.add("hidden");
document.querySelectorAll(".lang-option").forEach(b=>b.onclick=()=>{
  lang=b.dataset.lang;localStorage.setItem("mp_lang",lang);applyLang();$("#langModal").classList.add("hidden");
});

function saveAccess(data){
  localStorage.setItem("mp_access",JSON.stringify(data));showDashboard(data);
}
function showDashboard(data){
  $("#dashboard").classList.remove("hidden");
  $("#dashPlan").textContent=data.planLabel||"Access";
  const tick=()=>{
    const left=Math.max(0,data.expiresAt-Date.now());
    if(left<=0){$("#countdown").textContent=lang==="ru"?"СРОК ИСТЁК":"EXPIRED";$("#dashBadge").textContent="EXPIRED";localStorage.removeItem("mp_access");return}
    const s=Math.floor(left/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60),ss=s%60;
    $("#countdown").textContent=(d?d+"d ":"")+String(h).padStart(2,"0")+":"+String(m).padStart(2,"0")+":"+String(ss).padStart(2,"0");
  };tick();clearInterval(window.mpTimer);window.mpTimer=setInterval(tick,1000);
}
const old=localStorage.getItem("mp_access");if(old){try{const d=JSON.parse(old);if(d.expiresAt>Date.now())showDashboard(d)}catch{}}

$("#activateBtn").onclick=async()=>{
  const key=$("#keyInput").value.trim();const msg=$("#message");msg.textContent="";
  if(!key){msg.textContent=lang==="ru"?"Введи ключ.":"Enter a key.";return}
  $("#loader").classList.remove("hidden");$("#activationContent").classList.add("hidden");
  try{
    const r=await fetch(API_BASE+"/activate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({key})});
    if(!r.ok)throw new Error();
    const data=await r.json();
    if(!data.ok)throw new Error(data.message||"Invalid");
    saveAccess(data);
  }catch(e){
    msg.textContent=lang==="ru"?"Неверный или истёкший ключ.":"Invalid or expired key.";
  }finally{
    $("#loader").classList.add("hidden");$("#activationContent").classList.remove("hidden");
  }
};
