# Mirror Player Access Site

Black/white responsive access portal with:
- English/Russian language switch
- Mirror Player script card
- Copy latest raw Lua script
- 1h / 1d / 3d / 7d access plans
- Pro placeholder
- Server-side key activation
- Access countdown and expiry
- No neon styling

## Run

1. Install Node.js 18+.
2. `npm install`
3. Set `ADMIN_TOKEN` to a private value.
4. `npm start`

Open `http://localhost:3000`.

## Create a key

Send:

POST /api/admin/create-key
Authorization: Bearer YOUR_ADMIN_TOKEN
Content-Type: application/json

{"plan":"d1"}

Valid plans: h1, d1, d3, d7.

## Important

The browser must not be the authority for access. The real access state is checked by `/api/activate`.
For production, move keys from memory to a database and use authenticated admin/payment webhooks.

YouTube subscription/task completion should be verified server-side with an appropriate API/OAuth flow; the demo button is only a configurable outbound task link.
